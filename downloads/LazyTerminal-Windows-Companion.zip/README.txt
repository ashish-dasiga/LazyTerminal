Lazy Terminal � Windows PC Companion v1.0.0
===========================================
How to run:
1. Double-click LazyTerminal-Windows-Setup.bat OR run powershell -ExecutionPolicy Bypass -File LazyTerminal-Windows-Setup.ps1
2. Keep the command prompt window open.
3. Your browser will open to http://localhost:3000
4. Note the 6-digit pairing key displayed in the terminal window to connect your Android phone.
